package com.example.erukaclinet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceErukaclinetApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceErukaclinetApplication.class, args);
	}

}
