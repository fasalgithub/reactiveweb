package com.example.erukaclinet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceErukaclinetApplicationTests {

	@Test
	void contextLoads() {
	}

}
