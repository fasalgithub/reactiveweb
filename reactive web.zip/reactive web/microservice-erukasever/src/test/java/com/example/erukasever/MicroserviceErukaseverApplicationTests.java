package com.example.erukasever;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceErukaseverApplicationTests {

	@Test
	void contextLoads() {
	}

}
