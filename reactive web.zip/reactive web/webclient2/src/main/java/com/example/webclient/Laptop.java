package com.example.webclient;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Laptop 
{
	private int id;
	private String clientName;
	private String lapName;
	private String processer;

}
