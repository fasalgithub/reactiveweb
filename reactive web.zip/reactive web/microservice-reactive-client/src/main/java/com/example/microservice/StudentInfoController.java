package com.example.microservice;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentInfoController 
{
	
	@RequestMapping("/students")
	private List<StudentInfo> getAllMyStudentInfo() 
	{
		List<StudentInfo> listOfAllMyStudnets = new ArrayList<>();
		listOfAllMyStudnets.add(new StudentInfo(101, "riya", "pyton"));
		listOfAllMyStudnets.add(new StudentInfo(102, "sathya", "java"));
		listOfAllMyStudnets.add(new StudentInfo(103, "kirubakaran", "java"));
		return listOfAllMyStudnets;
	}

}
