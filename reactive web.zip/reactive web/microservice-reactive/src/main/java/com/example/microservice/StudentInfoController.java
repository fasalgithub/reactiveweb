package com.example.microservice;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@RestController
public class StudentInfoController 
{
	@Autowired
	RestTemplate restTemplate;
	
	
	/*
	@Autowired
	WebClient.Builder WebClientbuilder;
	*/
	
	@RequestMapping("/students-databases")
	private List<StudentInfo> getAllMyStudentInfo() throws RestClientException, URISyntaxException 
	{
	
		/*
		 * REACTIVE WEB WITHOUT WRAPPER
		 * 
		 StudentInfo[] studentInfos = WebClientbuilder
		.build()
		.get()
		.uri(new URI("http://localhost:8083/students"))
		.retrieve()
		.bodyToMono(StudentInfo[].class)
		.block();
		*/
		
		/*
		 * REACTIVE WEB WITH WRAPPER
		 * 
		 
		 return WebClientbuilder
		.build()
		.get()
		.uri(new URI("http://localhost:8083/students"))
		.retrieve()
		.bodyToMono(StudentCollection.class)
		.block();
		*/
		
	   
	      StudentInfo[] studentInfos = restTemplate.getForObject(new URI("http://student-provider:8083/students"), StudentInfo[].class);
		  return Arrays.asList(studentInfos);
			
		
   		

	}

}
